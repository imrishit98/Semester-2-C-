#include<iostream>
#include<string>
using namespace std;
class InventoryItem
{
   private:
      int stockNum;
      double price;
   public:
      void setStockNum(int);
      void setPrice(double);
      void display();
};
void InventoryItem::setStockNum(int stkNum)
{
    stockNum = stkNum;
}
void InventoryItem::setPrice(double pr)
{
    price = pr;
}
void InventoryItem::display()
{
   cout << "Item #" << stockNum << " costs $" <<
	   price << endl;
}
class Salesperson
{
   private:
      int idNum;
      string name;
   public:
      void setIdNum(int);
      void setName(string);
      void display();
};
void Salesperson::setIdNum(int id)
{
   idNum = id;
}
void Salesperson::setName(string lastName)
{
   name = lastName;
}   
void Salesperson::display()
{
   cout << "Salesperson #" << idNum << " " <<
	   name << endl;
}
class Transaction
{
   private:
      int transNum;
      InventoryItem itemSold;
      Salesperson seller;
   public:
      Transaction(int, int, double, int, string);
      void display();
};
Transaction::Transaction(int num, int item, double pr, 
   int salesId, string name)
{
   transNum = num;
   itemSold.setStockNum(item);
   itemSold.setPrice(pr);
   seller.setIdNum(salesId);
   seller.setName(name);
}
void Transaction::display()
{
   cout << "Data for transaction #" << transNum << endl;
   itemSold.display(); 
   seller.display();
}
int main()
{
   Transaction aSale(1533, 988, 22.95, 312, "Patterson");
   aSale.display();
   return 0;
}