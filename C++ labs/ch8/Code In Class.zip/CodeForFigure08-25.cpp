#include<iostream>
#include<string>
using namespace std;
class InventoryItem
{
   private:
      int stockNum;
      double price;
   public:
      InventoryItem(int, double);
      void display();
};
InventoryItem::InventoryItem(int stkNum, double pr)
{
    stockNum = stkNum;
    price = pr;
}
void InventoryItem::display()
{
   cout << "Item #" << stockNum << " costs $" <<
	   price << endl;
}
class Salesperson
{
   private:
      int idNum;
      string name;
   public:
      Salesperson(int, string);
      void display();
};
Salesperson::Salesperson(int id, string lastName)
{
   idNum = id;
   name = lastName;
}   
void Salesperson::display()
{
   cout << "Salesperson #" << idNum << " " <<
	   name << endl;
}
class Transaction
{
   private:
      int transNum;
      InventoryItem itemSold;
      Salesperson seller;
   public:
      Transaction(int, int, double, int, string);
      void display();
};
Transaction::Transaction(int num, int item, double pr, 
						 int salesId, string name) : itemSold(item, pr), seller(salesId, name)
{
   transNum = num;
}
void Transaction::display()
{
   cout << "Data for transaction #" << transNum << endl;
   itemSold.display(); 
   seller.display();
}
int main()
{
   Transaction aSale(247, 782, 44.77, 512, "Richardson");
   aSale.display();
   return 0;
}