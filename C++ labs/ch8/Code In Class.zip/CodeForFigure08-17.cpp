#include<iostream>
using namespace std;
class House
{
   private:
      int squareFeet;
   public:
       House();
      ~House();
      int getSquareFeet();
};
House::House()
{
   squareFeet = 1000;
   cout << "House created." << endl;
}
House::~House()
{
   cout << "House destroyed!" << endl;
}
int House::getSquareFeet()
{
   return squareFeet;
}
int main()
{
   void createHouse();
   int x;
   for(x = 0; x < 6; ++x)
      createHouse();
   return 0;
}
void createHouse()
{
   House aHouse;
   cout << "End of function" << endl;
}