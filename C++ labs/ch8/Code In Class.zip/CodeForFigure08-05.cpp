#include<iostream>
using namespace std;
class Employee
{
   private:
      int idNum;
      double hourlyRate;
   public:
      Employee();
      void setIdNum(const int);
      void setHourlyRate(const double);
      int getIdNum();
      double getHourlyRate();
};
Employee::Employee()
{
   idNum = 9999;
   hourlyRate = 6.15;
}
void Employee::setIdNum(const int id)
{
   idNum = id;
}
void Employee::setHourlyRate(const double rate)
{
   hourlyRate = rate;
}
int Employee::getIdNum()
{
   return idNum;
}
double Employee::getHourlyRate()
{
   return hourlyRate;
}
int main()
{
   Employee assistant;
   cout << "Before setting values" << endl;
   cout << " ID: " << assistant.getIdNum() <<
      " Rate: " << assistant.getHourlyRate() <<
      endl;
   assistant.setIdNum(4321);
   assistant.setHourlyRate(12.75);
   cout << "After setting values" << endl;
   cout << " ID: " << assistant.getIdNum() <<
      " Rate: " << assistant.getHourlyRate() <<
      endl;
   return 0;
}
