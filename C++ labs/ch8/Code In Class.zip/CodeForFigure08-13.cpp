#include<iostream>
using namespace std;
class House
{
   private:
      int squareFeet;
   public:
       House();
      ~House();
      int getSquareFeet();
};
House::House()
{
   squareFeet = 1000;
   cout << "House created." << endl;
}
House::~House()
{
   cout << "House destroyed!" << endl;
}
int House::getSquareFeet()
{
   return squareFeet;
}
int main()
{
   House aHouse;
   cout << "Square feet in house object = " <<
      aHouse.getSquareFeet() << endl;
   return 0;
}