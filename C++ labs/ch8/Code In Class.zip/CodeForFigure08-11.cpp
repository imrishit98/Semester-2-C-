#include<iostream>
#include<string>
using namespace std;
class Writer
{
   private:
      string firstName;
      string middleName;
      string lastName;
      // other data members go here
   public:
      Writer(string, string, string);
      Writer(string, string);
      string toString();
      // other functions go here
};
Writer::Writer(string first, string middle, string last)
{
   firstName = first;
   middleName = middle;
   lastName = last;
}
Writer::Writer(string first, string last)
{
   firstName = first;
   middleName = "";
   lastName = last;
}
string Writer::toString()
{
   
   string fullName;
   if(middleName != "")
      fullName = firstName + " " + middleName + " " + lastName;
   else
      fullName = firstName + " " + lastName;
   return fullName;
}
int main()
{
   Writer oneWriter("Edgar", "Allen", "Poe");
   Writer anotherWriter("Ernest", "Hemingway");
   cout << oneWriter.toString() << endl;
   cout << anotherWriter.toString() << endl;
   return 0;
}
